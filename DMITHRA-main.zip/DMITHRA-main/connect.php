<?php
$con=new mysqli('localhost','root','','dymithra');
// if($con)
//   echo "successful";
// else
//   echo "could not successful";


?>